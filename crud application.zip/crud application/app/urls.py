from lib2to3.pgen2.token import NAME
from unicodedata import name
from django.urls import path,include
from . import views

urlpatterns = [
    path("",views.InsertPageView,name="insertpage"), #you can give any name
    path("insert/",views.InsertData,name="insert"),
    path("showpage/",views.ShowPage,name="showpage"),
    path("editpage/<int:pk>",views.EditPage,name="editpage"),
    path("update/<int:pk>",views.UpdateData,name="update"),
    path("delete/<int:pk>",views.DeleteData,name="delete")

]
